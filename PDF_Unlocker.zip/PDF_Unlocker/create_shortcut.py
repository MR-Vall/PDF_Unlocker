import os
import winshell
from win32com.client import Dispatch

def create_shortcut(target, shortcut_name, description=""):
    desktop = winshell.desktop()
    path = os.path.join(desktop, f"{shortcut_name}.lnk")
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortcut(path)
    shortcut.TargetPath = target
    shortcut.WorkingDirectory = os.path.dirname(target)
    shortcut.Description = description
    shortcut.save()

if __name__ == "__main__":
    # Path to the executable
    target = os.path.abspath("PDF_Oplaaser.exe")
    # Name of the shortcut
    shortcut_name = "PDF Decrypt"
    # Description of the shortcut
    description = "Shortcut to PDF Decrypt tool"
    
    create_shortcut(target, shortcut_name, description)
    print(f"Shortcut created on desktop: {shortcut_name}.lnk")
